"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileContent = void 0;
class FileContent {
    constructor(name, relativePath, content) {
        this.isEmpty = false;
        this.name = name;
        this.relativePath = relativePath;
        this.content = content;
    }
}
exports.FileContent = FileContent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRmlsZUNvbnRlbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvRmlsZUNvbnRlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsTUFBYSxXQUFXO0lBTXBCLFlBQVksSUFBWSxFQUFFLFlBQW1CLEVBQUUsT0FBZTtRQUZ2RCxZQUFPLEdBQVksS0FBSyxDQUFDO1FBRzVCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFBO0lBQzFCLENBQUM7Q0FFSjtBQVpELGtDQVlDIn0=